<?php
// HB Sync — activarea licenței: max. 3 calculatoare per licență (e-mail), deconectare de pe calculator sau de la distanță.
// Cererea vine din aplicație: {action: activate|check|remove, name, key, device, device_name, target?}
require __DIR__ . '/_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
const HB_PUB = 'c04ee743a5d9729998dbf40fd8c7bda9e39c03ab92c4d8ac4cd46201f68e045b';
const HB_MAX_DEVICES = 3;
$out = function ($a, $code = 200) { http_response_code($code); echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; };

function hb_b32dec($s) {
    $alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
    foreach (str_split(rtrim($s, '=')) as $c) { $v = strpos($alpha, $c); if ($v === false) return false; $bits .= str_pad(decbin($v), 5, '0', STR_PAD_LEFT); }
    foreach (str_split($bits, 8) as $b) if (strlen($b) === 8) $out .= chr(bindec($b));
    return $out;
}
function hb_key_ok($name, $key) {
    // aceeași verificare ca în aplicație (license.parse_key): semnătură Ed25519 pe "HBSYNC1:<email>[:A:<YYYYMMDD>]"
    $name = strtolower(trim($name)); $k = strtoupper(str_replace(' ', '', trim($key))); $exp = null;
    if (preg_match('/^HBS-A(\d{8})-(.+)$/', $k, $m)) { $exp = $m[1]; $rest = $m[2]; }
    else $rest = strpos($k, 'HBS-') === 0 ? substr($k, 4) : $k;
    $sig = hb_b32dec(str_replace('-', '', $rest));
    if ($sig === false || strlen($sig) !== 64 || $name === '') return false;
    $msg = 'HBSYNC1:' . $name . ($exp ? ':A:' . $exp : '');
    if (!sodium_crypto_sign_verify_detached($sig, $msg, sodium_hex2bin(HB_PUB))) return false;
    if ($exp && date('Ymd') > $exp) return 'expired';
    return true;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(['ok' => false, 'err' => 'method'], 405);
if (!function_exists('sodium_crypto_sign_verify_detached')) $out(['ok' => false, 'err' => 'server'], 500);
$in = json_decode((string)file_get_contents('php://input'), true) ?: [];
$ip = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . 'hbsync');
if (!hb_rate_ok('lic:' . $ip, 60, 3600)) $out(['ok' => false, 'err' => 'rate'], 429);
$action = (string)($in['action'] ?? '');
$name = strtolower(trim((string)($in['name'] ?? '')));
$dev = substr(preg_replace('/[^a-f0-9]/', '', (string)($in['device'] ?? '')), 0, 32);
$devName = mb_substr(trim((string)($in['device_name'] ?? '')), 0, 80) ?: 'Calculator';
if (strlen($dev) < 16) $out(['ok' => false, 'err' => 'device'], 400);
if (!in_array($action, ['activate', 'check', 'remove'], true)) $out(['ok' => false, 'err' => 'action'], 400);
$k = hb_key_ok($name, (string)($in['key'] ?? ''));
if ($k === false) $out(['ok' => false, 'err' => 'key']);
// licență anuală expirată: nu se mai activează pe calculatoare noi, dar „check” și „remove” merg în continuare
if ($k === 'expired' && $action === 'activate') $out(['ok' => false, 'err' => 'expired']);

$db = hb_db(); $LI = hb_t('licenses'); $DV = hb_t('devices'); $now = hb_now();
$list = function () use ($db, $DV, $name) {
    $q = $db->prepare("SELECT device AS id, name, last_seen AS last FROM $DV WHERE email = ? ORDER BY first_seen"); $q->execute([$name]);
    return $q->fetchAll();
};
$db->beginTransaction();
$db->prepare("INSERT IGNORE INTO $LI (email, blocked, created) VALUES (?, 0, ?)")->execute([$name, $now]);
$q = $db->prepare("SELECT blocked FROM $LI WHERE email = ? FOR UPDATE"); $q->execute([$name]);   // un singur client odată pe licență
if ((int)$q->fetchColumn()) { $db->commit(); $out(['ok' => false, 'err' => 'blocked']); }
$q = $db->prepare("SELECT 1 FROM $DV WHERE email = ? AND device = ?"); $q->execute([$name, $dev]);
$here = (bool)$q->fetchColumn();
$res = null;
if ($action === 'activate') {
    if ($here) {
        $db->prepare("UPDATE $DV SET last_seen = ?, name = ? WHERE email = ? AND device = ?")->execute([$now, $devName, $name, $dev]);
    } else {
        $q = $db->prepare("SELECT COUNT(*) FROM $DV WHERE email = ?"); $q->execute([$name]);
        if ((int)$q->fetchColumn() >= HB_MAX_DEVICES) $res = ['ok' => false, 'err' => 'limit', 'max' => HB_MAX_DEVICES, 'devices' => $list()];
        else {
            $db->prepare("INSERT INTO $DV (email, device, name, first_seen, last_seen) VALUES (?,?,?,?,?)")->execute([$name, $dev, $devName, $now, $now]);
            hb_ga(null, 'hbsync_license_activate', ['hbs_plan' => $k === true && preg_match('/^HBS-A/i', trim((string)$in['key'])) ? 'anual' : 'viata', '_seed' => $name]);
        }
    }
    $res = $res ?: ['ok' => true, 'active' => true, 'max' => HB_MAX_DEVICES, 'devices' => $list()];
} elseif ($action === 'check') {
    if ($here) $db->prepare("UPDATE $DV SET last_seen = ? WHERE email = ? AND device = ?")->execute([$now, $name, $dev]);
    $res = ['ok' => true, 'active' => $here, 'max' => HB_MAX_DEVICES, 'devices' => $list()];
} else {   // remove: acest calculator sau, cu "target", alt calculator al aceleiași licențe
    $t = substr(preg_replace('/[^a-f0-9]/', '', (string)($in['target'] ?? $dev)), 0, 32);
    $db->prepare("DELETE FROM $DV WHERE email = ? AND device = ?")->execute([$name, $t]);
    $res = ['ok' => true, 'active' => $here && $t !== $dev, 'max' => HB_MAX_DEVICES, 'devices' => $list()];
}
$db->commit();
$out($res);
