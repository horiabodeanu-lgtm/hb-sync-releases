<?php
// HB Sync — actualizarea paginii și a fișierelor fără cPanel.
// Folosire (doar Horia / Claude): deploy.php?k=CHEIA_ADMIN  → descarcă pachetul publicat, îl verifică și îl instalează.
// Siguranță: pachetul trebuie să fie semnat cu cheia privată HB Sync (aceeași ca licențele). Un pachet nesemnat sau
// modificat e refuzat, chiar dacă cineva află linkul. config.php și hbsync-data/ nu se ating niciodată.
require __DIR__ . '/_lib.php';
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex');
const HB_PUB_DEPLOY = 'c04ee743a5d9729998dbf40fd8c7bda9e39c03ab92c4d8ac4cd46201f68e045b';
if (!hash_equals((string)$CFG['admin_key'], (string)($_GET['k'] ?? ''))) { http_response_code(404); exit('Not found'); }
@set_time_limit(300);
header('X-LiteSpeed-Purge: *');                    // golește cache-ul LiteSpeed (trebuie trimis înaintea textului)
$say = function ($m) { echo $m . "\n"; @ob_flush(); @flush(); };
$fail = function ($m) use ($say) { http_response_code(500); $say('EROARE: ' . $m); exit; };
if (!class_exists('ZipArchive')) $fail('PHP fără extensia zip (cPanel ▸ Select PHP Version ▸ bifează zip).');
if (!function_exists('sodium_crypto_sign_verify_detached')) $fail('PHP fără extensia sodium.');
$base = rtrim($CFG['deploy_url'] ?? 'https://raw.githubusercontent.com/horiabodeanu-lgtm/hb-sync-releases/main/', '/') . '/';
hb_data_dir();
$tmp = HB_DATA . '/deploy'; @mkdir($tmp, 0750, true);
$get = function ($url) {
    $ctx = stream_context_create(['http' => ['timeout' => 240, 'header' => "User-Agent: HBSync-deploy\r\nCache-Control: no-cache\r\n"]]);
    return @file_get_contents($url . '?t=' . time(), false, $ctx);
};
$say('Descarc pachetul de la ' . $base . ' …');
$zip = $get($base . 'hb-sync-site.zip');
$sig = trim((string)$get($base . 'hb-sync-site.zip.sig'));
if (!$zip || strlen($zip) < 1000) $fail('nu am putut descărca pachetul.');
$sigb = base64_decode($sig, true);
$msg = 'HBSYNCDEPLOY1|' . hash('sha256', $zip);
if (!$sigb || strlen($sigb) !== 64 || !sodium_crypto_sign_verify_detached($sigb, $msg, sodium_hex2bin(HB_PUB_DEPLOY)))
    $fail('semnătura pachetului nu e validă — nu instalez nimic.');
$say('Semnătura e validă (' . round(strlen($zip) / 1048576, 1) . ' MB).');
file_put_contents("$tmp/pachet.zip", $zip); unset($zip);
$z = new ZipArchive();
if ($z->open("$tmp/pachet.zip") !== true) $fail('arhiva nu se poate deschide.');
// copie de siguranță a fișierelor actuale (fără installer, ca să nu ocupe spațiu)
$bk = HB_DATA . '/backups'; @mkdir($bk, 0750, true);
$b = new ZipArchive(); $bkname = "$bk/inainte-" . date('Ymd-His') . '.zip';
if ($b->open($bkname, ZipArchive::CREATE) === true) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(__DIR__, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        $rel = substr($f->getPathname(), strlen(__DIR__) + 1);
        if (strpos($rel, 'hbsync-data') === 0 || preg_match('/\.(exe|zip|mp4)$/i', $rel)) continue;
        $b->addFile($f->getPathname(), $rel);
    }
    $b->close();
    $old = glob("$bk/inainte-*.zip"); sort($old);
    foreach (array_slice($old, 0, max(0, count($old) - 5)) as $o) @unlink($o);    // păstrează ultimele 5
    $say('Copie de siguranță: ' . basename($bkname));
}
$n = 0; $skip = 0;
for ($i = 0; $i < $z->numFiles; $i++) {
    $name = $z->getNameIndex($i);
    if (substr($name, -1) === '/' || strpos($name, '..') !== false || $name[0] === '/') continue;
    if ($name === 'config.php' || strpos($name, 'hbsync-data/') === 0) { $skip++; continue; }   // setările și datele rămân
    $dst = __DIR__ . '/' . $name;
    @mkdir(dirname($dst), 0755, true);
    $in = $z->getStream($name);
    $t = $dst . '.tmp' . getmypid();
    $out = fopen($t, 'wb');
    if (!$in || !$out) $fail("nu pot scrie $name");
    stream_copy_to_stream($in, $out); fclose($out); fclose($in);
    if (!@rename($t, $dst)) { @unlink($t); $fail("nu pot înlocui $name"); }
    $n++;
}
$z->close(); @unlink("$tmp/pachet.zip");
$say("Gata: $n fișiere actualizate ($skip păstrate neatinse). Versiunea de pe site: " . hb_version());
