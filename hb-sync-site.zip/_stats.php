<?php
// HB Sync — statistici pentru leads.php, calculate din datele deja citite (fără SQL specific).
function hb_stats(array $leads, array $free, array $devs, array $lic, array $repDates, string $today): array {
    $d = fn($s) => substr((string)$s, 0, 10);
    $ago = fn($n) => date('Y-m-d', strtotime("$today -$n days"));
    $days = []; for ($i = 29; $i >= 0; $i--) $days[$ago($i)] = ['leads' => 0, 'dl' => 0, 'free' => 0];
    $since = fn($rows, $col, $n) => count(array_filter($rows, fn($r) => $d($r[$col]) >= $GLOBALS['__hb_ago']($n)));
    $GLOBALS['__hb_ago'] = $ago;
    foreach ($leads as $r) { if (isset($days[$d($r['created'])])) $days[$d($r['created'])]['leads']++; if ($r['last_download'] && isset($days[$d($r['last_download'])])) $days[$d($r['last_download'])]['dl']++; }
    foreach ($free as $r) if (isset($days[$d($r['created'])])) $days[$d($r['created'])]['free']++;
    $evPerDev = []; foreach ($free as $r) $evPerDev[$r['device']] = ($evPerDev[$r['device']] ?? 0) + 1;
    $active = fn($n) => count(array_unique(array_map(fn($r) => $r['device'], array_filter($devs, fn($r) => $d($r['last_seen']) >= $ago($n))))) ;
    $n = count($leads); $dl = count(array_filter($leads, fn($r) => $r['downloads'] > 0));
    $licOk = array_filter($lic, fn($r) => !$r['blocked']);
    $ver = @json_decode(@file_get_contents(__DIR__ . '/version.json'), true)['version'] ?? '?';
    return [
        'site_version' => $ver,
        'leads' => $n, 'leads_today' => $since($leads, 'created', 0), 'leads_7' => $since($leads, 'created', 6), 'leads_30' => $since($leads, 'created', 29),
        'dl_people' => $dl, 'dl_total' => array_sum(array_column($leads, 'downloads')),
        'dl_win' => array_sum(array_column($leads, 'dl_win')), 'dl_mac' => array_sum(array_column($leads, 'dl_mac')),
        'news' => count(array_filter($leads, fn($r) => $r['news'])), 'unsub' => count(array_filter($leads, fn($r) => $r['unsubscribed'])),
        'never_dl' => $n - $dl,
        'lang' => array_count_values(array_map(fn($r) => $r['lang'], $leads)), 'plat' => array_count_values(array_map(fn($r) => $r['platform'], $leads)),
        'lic' => count($licOk), 'lic_blocked' => count($lic) - count($licOk), 'lic_pcs' => count($devs),
        'pcs_7' => $active(6), 'pcs_30' => $active(29),
        'free_pcs' => count($evPerDev), 'free_events' => count($free), 'free_full' => count(array_filter($evPerDev, fn($v) => $v >= 3)),
        'free_7' => $since($free, 'created', 6),
        'reports_7' => count(array_filter($repDates, fn($x) => $x >= $ago(6))), 'reports' => count($repDates),
        'days' => $days,
    ];
}
function hb_pct($a, $b) { return $b ? round(100 * $a / $b) . ' %' : '—'; }
function hb_bars(array $days, string $key, string $cls, string $title, callable $e): string {
    $max = max(1, max(array_column($days, $key))); $o = '<h3 style="font-size:14px;margin:0 0 6px;color:#8fa2c4">' . $e($title) . '</h3><div class="bars">';
    foreach ($days as $day => $v) $o .= '<i class="' . $cls . '" style="height:' . round(100 * $v[$key] / $max) . '%" data-t="' . $e(date('d.m', strtotime($day))) . ': ' . (int)$v[$key] . '"></i>';
    $k = array_keys($days); return $o . '<span class="ax" style="left:12px">' . date('d.m', strtotime($k[0])) . '</span><span class="ax" style="right:12px">azi</span></div>';
}
function hb_split(array $counts, array $colors, callable $e): string {
    $t = array_sum($counts); if (!$t) return '<p style="color:#5b6d8f">—</p>';
    $o = '<div class="split">'; $i = 0;
    foreach ($counts as $k => $v) { $o .= '<span style="width:' . (100 * $v / $t) . '%;background:' . $colors[$i++ % count($colors)] . '">' . $e(strtoupper($k)) . ' ' . (int)$v . '</span>'; }
    return $o . '</div>';
}
function hb_stats_html(array $S, callable $e): string {
    $k = fn($v, $label, $sub = '') => '<div><b>' . $v . '</b>' . $e($label) . ($sub !== '' ? '<small>' . $e($sub) . '</small>' : '') . '</div>';
    $o = '<h2>Statistici</h2><div class="k">'
       . $k($S['leads'], 'e-mailuri', 'azi ' . $S['leads_today'] . ' · 7 zile ' . $S['leads_7'] . ' · 30 zile ' . $S['leads_30'])
       . $k($S['dl_people'], 'au descărcat', hb_pct($S['dl_people'], $S['leads']) . ' din e-mailuri · ' . $S['never_dl'] . ' n-au descărcat')
       . $k($S['dl_total'], 'descărcări', $S['dl_win'] . ' Windows · ' . $S['dl_mac'] . ' Mac')
       . $k($S['news'], 'vor noutăți', hb_pct($S['news'], $S['leads']) . ' · ' . $S['unsub'] . ' dezabonați')
       . $k($S['free_pcs'], 'folosesc gratuit', $S['free_events'] . ' evenimente · 7 zile ' . $S['free_7'])
       . $k($S['free_full'], 'au terminat cele 3 gratuite', 'potențiali clienți')
       . $k($S['lic'], 'licențe active', $S['lic_pcs'] . ' calculatoare · ' . $S['lic_blocked'] . ' blocate')
       . $k(hb_pct($S['lic'], $S['dl_people']), 'conversie', 'licențe / cei care au descărcat')
       . $k($S['pcs_7'], 'calculatoare cu licență active', '7 zile · 30 zile: ' . $S['pcs_30'])
       . $k($S['reports_7'], 'rapoarte de probleme', '7 zile · total ' . $S['reports'])
       . '</div><div class="g2"><div>' . hb_bars($S['days'], 'leads', '', 'E-mailuri noi pe zi (30 zile)', $e) . '</div><div>'
       . hb_bars($S['days'], 'free', 'f', 'Evenimente gratuite folosite pe zi (30 zile)', $e) . '</div></div>'
       . '<div class="g2" style="margin-top:14px"><div><h3 style="font-size:14px;margin:0;color:#8fa2c4">Limba</h3>' . hb_split($S['lang'], ['#3b82f6', '#38bdf8'], $e)
       . '</div><div><h3 style="font-size:14px;margin:0;color:#8fa2c4">Sistem</h3>' . hb_split($S['plat'], ['#3b82f6', '#a78bfa'], $e) . '</div></div>';
    return $o;
}
