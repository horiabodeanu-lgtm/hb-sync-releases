<?php
// HB Sync — „Raportează o problemă” din aplicație: salvează raportul și îl trimite pe e-mail.
require __DIR__ . '/_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$out = function ($a, $code = 200) { http_response_code($code); echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; };
if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(['ok' => false], 405);
$raw = (string)file_get_contents('php://input', false, null, 0, 4000000);
$in = json_decode($raw, true);
if (!is_array($in)) $out(['ok' => false, 'err' => 'format'], 400);
$ip = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . 'hbsync');
if (!hb_rate_ok('rep:' . $ip, 10, 3600)) $out(['ok' => false, 'err' => 'rate'], 429);
$clip = fn($s, $n) => mb_substr((string)$s, 0, $n);
$r = [
    'id' => date('Ymd-His') . '-' . bin2hex(random_bytes(3)),
    'when' => date('c'),
    'kind' => $clip($in['kind'] ?? 'manual', 20),
    'email' => $clip($in['email'] ?? '', 190),
    'message' => $clip($in['message'] ?? '', 5000),
    'version' => $clip($in['version'] ?? '', 20),
    'system' => $clip($in['system'] ?? '', 500),
    'licence' => $clip($in['licence'] ?? '', 200),
    'error' => $clip($in['error'] ?? '', 20000),
    'log' => $clip($in['log'] ?? '', 800000),
];
hb_data_dir();
$dir = HB_DATA . '/rapoarte';
if (!is_dir($dir)) @mkdir($dir, 0750, true);
file_put_contents("$dir/{$r['id']}.json", json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
$to = $CFG['notify'] ?: $CFG['reply_to'];
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$subj = 'HB Sync: ' . ($r['kind'] === 'eroare' ? 'eroare' : 'raport problemă') . ' ' . $r['version'] . ($r['email'] ? ' — ' . $r['email'] : '');
$txt = "Raport {$r['id']} ({$r['kind']})\nDe la: {$r['email']}\nVersiune: {$r['version']}\nSistem: {$r['system']}\nLicență: {$r['licence']}\n\nMesaj:\n{$r['message']}\n\nEroare:\n{$r['error']}\n\nJurnal (ultimele rânduri):\n" . mb_substr($r['log'], -15000);
$html = '<pre style="font:13px Consolas,monospace;white-space:pre-wrap">' . $e($txt) . '</pre>';
hb_mail($to, $subj, $html, $txt, $r['email']);
$out(['ok' => true, 'id' => $r['id']]);
