<?php
// HB Sync — primește e-mailul din pagină, îl salvează în baza de date a site-ului și trimite linkul de descărcare
require __DIR__ . '/_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$out = function ($a, $code = 200) { http_response_code($code); echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; };
if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(['ok' => false, 'err' => 'method'], 405);
$in = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($in)) $in = $_POST;
if (!empty($in['website'])) $out(['ok' => true, 'sent' => true]);            // capcană pentru roboți
$email = strtolower(trim((string)($in['email'] ?? '')));
$lang = (($in['lang'] ?? 'ro') === 'en') ? 'en' : 'ro';
$plat = (($in['platform'] ?? 'win') === 'mac') ? 'mac' : 'win';
$news = !empty($in['news']);
$cid = preg_match('/^\d{5,12}\.\d{5,12}$/', (string)($in['cid'] ?? '')) ? $in['cid'] : null;   // client_id GA4 (din cookie-ul _ga)
if (strlen($email) > 190 || !filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/\.[a-z]{2,}$/', $email))
    $out(['ok' => false, 'err' => 'email'], 400);
$ip = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . 'hbsync');
if (!hb_rate_ok('ip:' . $ip, 8, 3600)) $out(['ok' => false, 'err' => 'rate'], 429);
if (!hb_rate_ok('em:' . $email, 3, 600) || !hb_rate_ok('em24:' . $email, 6, 86400)) $out(['ok' => false, 'err' => 'rate'], 429);

$db = hb_db(); $L = hb_t('leads'); $now = hb_now();
$db->beginTransaction();
$q = $db->prepare("SELECT * FROM $L WHERE email = ? FOR UPDATE"); $q->execute([$email]);
$lead = $q->fetch();
$isNew = !$lead;
if ($isNew) {
    $db->prepare("INSERT INTO $L (email, created, lang, platform, news, news_at, token, token_at, ga_cid, ip) VALUES (?,?,?,?,?,?,?,?,?,?)")
       ->execute([$email, $now, $lang, $plat, $news ? 1 : 0, $news ? $now : null, bin2hex(random_bytes(16)), $now, $cid, hb_ip()]);
}
$set = ['lang = ?', 'platform = ?', 'requests = requests + 1', 'last_request = ?'];
$args = [$lang, $plat, $now];
if ($news) { $set[] = 'news = 1'; $set[] = 'unsubscribed = 0'; $set[] = 'news_at = COALESCE(news_at, ?)'; $args[] = $now; }
if ($cid) { $set[] = 'ga_cid = ?'; $args[] = $cid; }
if (!$isNew && strtotime($lead['token_at']) < time() - 86400 * ($CFG['link_days'] - 1)) {   // link nou, ca să nu expire curând
    $set[] = 'token = ?'; $set[] = 'token_at = ?'; $args[] = bin2hex(random_bytes(16)); $args[] = $now;
}
$args[] = $email;
$db->prepare("UPDATE $L SET " . implode(', ', $set) . ' WHERE email = ?')->execute($args);
$db->commit();
$q = $db->prepare("SELECT * FROM $L WHERE email = ?"); $q->execute([$email]); $lead = $q->fetch();

$sent = hb_link_mail($lead);
if ($isNew && $CFG['notify']) {
    hb_mail($CFG['notify'], 'HB Sync: descărcare nouă — ' . $email,
        '<p>' . htmlspecialchars($email) . ' (' . $lang . ', ' . $plat . ($news ? ', vrea noutăți' : '') . ')</p>',
        "$email ($lang, $plat" . ($news ? ', vrea noutăți' : '') . ")\n");
}
$res = ['ok' => true, 'sent' => (bool)$sent];
if (!$CFG['link_only_by_email']) $res['url'] = 'd.php?t=' . $lead['token'] . '&p=' . $plat;
$out($res);
