<?php
// HB Sync — linkul din e-mail: verifică tokenul și pornește descărcarea (sau dezabonarea, cu confirmare)
require __DIR__ . '/_lib.php';
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex');
$t = preg_replace('/[^a-f0-9]/', '', (string)($_GET['t'] ?? ''));
$p = (string)($_GET['p'] ?? 'win');
$page = function ($en, $msg, $form = '') {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>HB Sync</title>'
       . '<body style="background:#070d1a;color:#e7eefb;font-family:Segoe UI,Arial,sans-serif;display:grid;place-items:center;min-height:90vh;margin:0;padding:16px">'
       . '<div style="max-width:440px;text-align:center"><h1 style="font-size:22px">HB Sync</h1><p style="color:#8fa2c4">' . htmlspecialchars($msg) . '</p>' . $form
       . '<p><a style="color:#60a5fa" href="' . htmlspecialchars(hb_base() . ($en ? 'en/' : '')) . '">horiabodeanu.ro/hb-sync</a></p></div>';
    exit;
};
if ($p === 'unsub') {
    $en = ($_GET['l'] ?? '') === 'en';
    if ($_SERVER['REQUEST_METHOD'] !== 'POST')       // scanerele de linkuri din e-mail nu dezabonează pe nimeni din greșeală
        $page($en, $en ? 'Stop receiving HB Sync emails?' : 'Nu mai vrei e-mailuri de la HB Sync?',
              '<form method="post"><button style="background:#3b82f6;color:#fff;border:0;border-radius:10px;padding:12px 22px;font-size:15px;cursor:pointer">'
              . ($en ? 'Unsubscribe' : 'Dezabonează-mă') . '</button></form>');
    $q = hb_db()->prepare('UPDATE ' . hb_t('leads') . ' SET news = 0, unsubscribed = 1, unsub_at = ? WHERE token = ?');
    $q->execute([hb_now(), $t]);
    $page($en, $q->rowCount() ? ($en ? 'You are unsubscribed. You will not get any more emails from HB Sync.' : 'Te-ai dezabonat. Nu mai primești e-mailuri de la HB Sync.')
                              : ($en ? 'Link not valid.' : 'Link invalid.'));
}
$plat = $p === 'mac' ? 'mac' : 'win';
$lead = null;
if (strlen($t) === 32) {
    $q = hb_db()->prepare('SELECT * FROM ' . hb_t('leads') . ' WHERE token = ?'); $q->execute([$t]); $lead = $q->fetch() ?: null;
}
$en = ($lead['lang'] ?? 'ro') === 'en';
$back = hb_base() . ($en ? 'en/' : '');
if (!$lead) { header('Location: ' . $back . '?link=invalid#descarca', true, 302); exit; }
if (strtotime($lead['token_at']) < time() - 86400 * $CFG['link_days']) { header('Location: ' . $back . '?link=expirat#descarca', true, 302); exit; }
hb_db()->prepare('UPDATE ' . hb_t('leads') . " SET downloads = downloads + 1, dl_$plat = dl_$plat + 1, last_download = ? WHERE email = ?")
       ->execute([hb_now(), $lead['email']]);
hb_ga($lead['ga_cid'], 'hbsync_file_download', ['hbs_platform' => $plat, 'hbs_lang' => $lead['lang'], 'hbs_location' => 'email_link', '_seed' => $lead['email']]);
header('Location: ' . hb_base() . $CFG['files'][$plat] . '?v=' . rawurlencode(hb_version()), true, 302);
