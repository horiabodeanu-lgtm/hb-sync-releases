<?php
// HB Sync — numărul de sincronizări (de la 1.7.0). Aplicația trimite, după fiecare export, un rând anonim:
// versiunea, sistemul, câte clipuri / aparate / minute, modul (licență / gratuit / demo), amprenta calculatorului
// și, doar pentru licențe, e-mailul licenței. Fără nume de fișiere, fără conținut.
require __DIR__ . '/_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$out = function ($a, $code = 200) { http_response_code($code); echo json_encode($a); exit; };
if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(['ok' => false, 'err' => 'method'], 405);
$in = json_decode((string)file_get_contents('php://input'), true) ?: [];
if (($in['action'] ?? '') !== 'sync') $out(['ok' => false, 'err' => 'action'], 400);
$hex = fn($k) => substr(preg_replace('/[^a-f0-9]/', '', (string)($in[$k] ?? '')), 0, 32);
$dev = $hex('device'); $mac = $hex('mac');
if (strlen($dev) < 16) $out(['ok' => false, 'err' => 'device'], 400);
if (!hb_rate_ok('stat:' . hb_ip(), 300, 3600)) $out(['ok' => false, 'err' => 'rate'], 429);
$num = fn($k, $max) => max(0, min($max, (int)($in[$k] ?? 0)));
$mode = in_array($in['mode'] ?? '', ['licenta', 'gratuit', 'demo'], true) ? $in['mode'] : '';
$db = hb_db();
// e-mailul se păstrează doar dacă licența chiar e activată pe acest calculator (nu se poate trece alt e-mail)
$email = strtolower(trim((string)($in['email'] ?? '')));
if ($email !== '') {
    $q = $db->prepare('SELECT 1 FROM ' . hb_t('devices') . ' WHERE email = ? AND device = ? LIMIT 1'); $q->execute([$email, $dev]);
    if (!$q->fetchColumn()) $email = '';
}
$db->prepare('INSERT INTO ' . hb_t('syncs') . ' (device, mac, email, mode, event, ver, os, clips, cams, minutes, ip, created) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
   ->execute([$dev, $mac, substr($email, 0, 190), $mode, substr(preg_replace('/[^a-z0-9]/', '', (string)($in['event'] ?? '')), 0, 16),
              substr(preg_replace('/[^0-9a-z.]/', '', (string)($in['ver'] ?? '')), 0, 16), in_array($in['os'] ?? '', ['win', 'mac', 'linux'], true) ? $in['os'] : '',
              $num('clips', 100000), $num('cams', 500), $num('minutes', 100000), hb_ip(), hb_now()]);
$out(['ok' => true]);
