<?php
// HB Sync — varianta gratuită: 3 evenimente complete pe calculator, ținute minte pe server.
// Calculatorul e recunoscut după amprenta anonimă a sistemului (device) SAU a plăcii de rețea (mac), deci ștergerea
// fișierelor locale ori o descărcare nouă cu alt e-mail nu dau evenimente gratuite în plus.
require __DIR__ . '/_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
const HB_FREE_EVENTS = 3;
$out = function ($a, $code = 200) { http_response_code($code); echo json_encode($a); exit; };
if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(['ok' => false, 'err' => 'method'], 405);
$in = json_decode((string)file_get_contents('php://input'), true) ?: [];
$dev = substr(preg_replace('/[^a-f0-9]/', '', (string)($in['device'] ?? '')), 0, 32);
$mac = substr(preg_replace('/[^a-f0-9]/', '', (string)($in['mac'] ?? '')), 0, 32);
$ev = substr(preg_replace('/[^a-z0-9]/', '', (string)($in['event'] ?? '')), 0, 16);
$action = (string)($in['action'] ?? '');
if (strlen($dev) < 16 || strlen($mac) < 16) $out(['ok' => false, 'err' => 'device'], 400);
if (!hb_rate_ok('free:' . hb_ip(), 120, 3600)) $out(['ok' => false, 'err' => 'rate'], 429);
$db = hb_db(); $F = hb_t('free');
$used = function () use ($db, $F, $dev, $mac) {
    $q = $db->prepare("SELECT COUNT(DISTINCT event) FROM $F WHERE device = ? OR mac = ?"); $q->execute([$dev, $mac]);
    return (int)$q->fetchColumn();
};
if ($action === 'status') $out(['ok' => true, 'used' => $used(), 'max' => HB_FREE_EVENTS]);
if ($action !== 'use' || strlen($ev) < 6) $out(['ok' => false, 'err' => 'action'], 400);
$db->beginTransaction();
$q = $db->prepare("SELECT 1 FROM $F WHERE (device = ? OR mac = ?) AND event = ? LIMIT 1 FOR UPDATE"); $q->execute([$dev, $mac, $ev]);
if ($q->fetchColumn()) { $db->commit(); $out(['ok' => true, 'used' => $used(), 'again' => true]); }   // același eveniment, reexportat
$n = $used();
if ($n >= HB_FREE_EVENTS) { $db->commit(); $out(['ok' => false, 'err' => 'used', 'used' => $n, 'max' => HB_FREE_EVENTS]); }
$db->prepare("INSERT IGNORE INTO $F (device, mac, event, ip, created) VALUES (?,?,?,?,?)")->execute([$dev, $mac, $ev, hb_ip(), hb_now()]);
$db->commit();
hb_ga(null, 'hbsync_free_event', ['hbs_count' => $n + 1, '_seed' => $dev]);
$out(['ok' => true, 'used' => $n + 1, 'max' => HB_FREE_EVENTS]);
