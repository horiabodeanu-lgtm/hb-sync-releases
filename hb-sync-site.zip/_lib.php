<?php
// HB Sync — funcții comune pentru descărcarea pe bază de e-mail
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === '_lib.php') { http_response_code(404); exit; }
date_default_timezone_set('Europe/Bucharest');
$CFG = require __DIR__ . '/config.php';
define('HB_DATA', __DIR__ . '/hbsync-data');

function hb_data_dir() {
    // folder pentru rapoartele de probleme (fișiere mari) + protecția lui
    if (!is_dir(HB_DATA) && !@mkdir(HB_DATA, 0750, true)) hb_fail('storage');
    if (!is_file(HB_DATA . '/.htaccess'))
        @file_put_contents(HB_DATA . '/.htaccess', "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n");
    if (!is_file(HB_DATA . '/index.html')) @file_put_contents(HB_DATA . '/index.html', '');
}
function hb_fail($why) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'err' => 'server', 'why' => $why]);
    exit;
}

/* ------------------------------------------------------------------ baza de date (MySQL-ul site-ului)
   Implicit se folosesc datele de conectare din wp-config.php (fără să se încarce WordPress și fără să se modifice
   nimic din el). Tabelele HB Sync au prefixul WordPress + "hbsync_" (ex. wp_hbsync_leads) și se creează singure. */
function hb_dbconf() {
    global $CFG;
    $c = $CFG['db'] ?? 'wordpress';
    if (is_array($c)) return $c + ['prefix' => 'hbsync_', 'port' => null];
    foreach ([dirname(__DIR__) . '/wp-config.php', dirname(__DIR__, 2) . '/wp-config.php'] as $f) {
        if (!is_file($f)) continue;
        $src = (string)file_get_contents($f);
        $get = function ($k) use ($src) {
            return preg_match("/define\(\s*['\"]" . $k . "['\"]\s*,\s*(['\"])(.*?)\\1\s*\)/s", $src, $m) ? stripcslashes($m[2]) : null;
        };
        $pre = preg_match('/\$table_prefix\s*=\s*([\'"])(.*?)\1/', $src, $m) ? $m[2] : 'wp_';
        if ($get('DB_NAME') === null) continue;
        $host = $get('DB_HOST') ?: 'localhost'; $port = null; $sock = null;
        if (strpos($host, ':') !== false) {
            [$host, $rest] = explode(':', $host, 2);
            if (ctype_digit($rest)) $port = (int)$rest; else $sock = $rest;
        }
        return ['host' => $host, 'port' => $port, 'socket' => $sock, 'name' => $get('DB_NAME'), 'user' => $get('DB_USER'),
                'pass' => $get('DB_PASSWORD'), 'prefix' => $pre . 'hbsync_'];
    }
    return null;
}
function hb_db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = hb_dbconf();
    if (!$c) hb_fail('db-config');
    $dsn = !empty($c['socket']) ? "mysql:unix_socket={$c['socket']};dbname={$c['name']};charset=utf8mb4"
         : "mysql:host={$c['host']};" . (!empty($c['port']) ? "port={$c['port']};" : '') . "dbname={$c['name']};charset=utf8mb4";
    try {
        $pdo = new PDO($dsn, $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                       PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
        $pdo->exec("SET time_zone = '" . date('P') . "'");
    } catch (Throwable $e) { hb_fail('db-connect'); }
    hb_schema($pdo);
    return $pdo;
}
function hb_t($name) { $c = hb_dbconf(); return '`' . preg_replace('/[^A-Za-z0-9_]/', '', $c['prefix'] . $name) . '`'; }
function hb_schema(PDO $db) {
    $v = 3;   // versiunea schemei; tabelele se creează / completează o singură dată
    $flag = HB_DATA . '/.schema' . $v . '-' . substr(md5(hb_t('x')), 0, 8);
    if (is_file($flag)) return;
    $o = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $db->exec('CREATE TABLE IF NOT EXISTS ' . hb_t('leads') . " (
        email VARCHAR(190) NOT NULL PRIMARY KEY, created DATETIME NOT NULL, lang CHAR(2) NOT NULL DEFAULT 'ro',
        platform VARCHAR(8) NOT NULL DEFAULT 'win', news TINYINT(1) NOT NULL DEFAULT 0, news_at DATETIME NULL,
        token CHAR(32) NOT NULL, token_at DATETIME NOT NULL, requests INT NOT NULL DEFAULT 0, downloads INT NOT NULL DEFAULT 0,
        dl_win INT NOT NULL DEFAULT 0, dl_mac INT NOT NULL DEFAULT 0, last_request DATETIME NULL, last_download DATETIME NULL,
        unsubscribed TINYINT(1) NOT NULL DEFAULT 0, unsub_at DATETIME NULL, ga_cid VARCHAR(64) NULL, UNIQUE KEY token (token)) $o");
    $db->exec('CREATE TABLE IF NOT EXISTS ' . hb_t('licenses') . " (
        email VARCHAR(190) NOT NULL PRIMARY KEY, blocked TINYINT(1) NOT NULL DEFAULT 0, created DATETIME NOT NULL) $o");
    $db->exec('CREATE TABLE IF NOT EXISTS ' . hb_t('devices') . " (
        email VARCHAR(190) NOT NULL, device CHAR(32) NOT NULL, name VARCHAR(80) NOT NULL, first_seen DATETIME NOT NULL,
        last_seen DATETIME NOT NULL, PRIMARY KEY (email, device)) $o");
    $db->exec('CREATE TABLE IF NOT EXISTS ' . hb_t('rate') . " (k VARCHAR(120) NOT NULL, ts INT NOT NULL, KEY k (k, ts)) $o");
    // varianta gratuită: evenimentele folosite pe fiecare calculator (amprentă anonimă a calculatorului + a plăcii de rețea)
    $db->exec('CREATE TABLE IF NOT EXISTS ' . hb_t('free') . " (
        device CHAR(32) NOT NULL, mac CHAR(32) NOT NULL, event VARCHAR(16) NOT NULL, ip CHAR(16) NOT NULL DEFAULT '',
        created DATETIME NOT NULL, PRIMARY KEY (device, event), KEY mac (mac), KEY ip (ip)) $o");
    // sincronizările făcute în aplicație (de la 1.7.0): un rând per export, fără nume de fișiere
    $db->exec('CREATE TABLE IF NOT EXISTS ' . hb_t('syncs') . " (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, device CHAR(32) NOT NULL, mac CHAR(32) NOT NULL DEFAULT '',
        email VARCHAR(190) NOT NULL DEFAULT '', mode VARCHAR(8) NOT NULL DEFAULT '', event VARCHAR(16) NOT NULL DEFAULT '',
        ver VARCHAR(16) NOT NULL DEFAULT '', os VARCHAR(8) NOT NULL DEFAULT '', clips INT NOT NULL DEFAULT 0, cams INT NOT NULL DEFAULT 0,
        minutes INT NOT NULL DEFAULT 0, ip CHAR(16) NOT NULL DEFAULT '', created DATETIME NOT NULL,
        KEY device (device), KEY email (email), KEY created (created)) $o");
    try { $db->exec('ALTER TABLE ' . hb_t('leads') . " ADD COLUMN ip CHAR(16) NOT NULL DEFAULT ''"); } catch (Throwable $e) {}   // există deja
    hb_data_dir();
    @file_put_contents($flag, date('c'));
}
function hb_now() { return date('Y-m-d H:i:s'); }
function hb_ip() { return substr(hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . 'hbsync-ip'), 0, 16); }   // IP anonimizat
function hb_rate_ok($key, $max, $window) {
    $db = hb_db(); $now = time();
    if (mt_rand(1, 50) === 1) $db->prepare('DELETE FROM ' . hb_t('rate') . ' WHERE ts < ?')->execute([$now - 86400 * 2]);
    $q = $db->prepare('SELECT COUNT(*) FROM ' . hb_t('rate') . ' WHERE k = ? AND ts > ?');
    $q->execute([$key, $now - $window]);
    if ((int)$q->fetchColumn() >= $max) return false;
    $db->prepare('INSERT INTO ' . hb_t('rate') . ' (k, ts) VALUES (?, ?)')->execute([$key, $now]);
    return true;
}

/* ------------------------------------------------------------------ GA4 (Measurement Protocol) pentru ce se întâmplă pe server */
function hb_ga($cid, $name, array $params = []) {
    global $CFG;
    if (empty($CFG['ga4_id']) || empty($CFG['ga4_secret'])) return;
    $cid = $cid ?: ('srv.' . substr(hash('sha256', 'hbsync' . ($params['_seed'] ?? mt_rand())), 0, 16));
    unset($params['_seed']);
    $body = json_encode(['client_id' => $cid, 'events' => [['name' => $name, 'params' => $params + ['engagement_time_msec' => 1, 'hbs_source' => 'server']]]]);
    $url = 'https://www.google-analytics.com/mp/collect?measurement_id=' . rawurlencode($CFG['ga4_id']) . '&api_secret=' . rawurlencode($CFG['ga4_secret']);
    if (getenv('HBSYNC_MAIL_LOG')) { file_put_contents(getenv('HBSYNC_MAIL_LOG'), "GA4: $name $body\n", FILE_APPEND); return; }
    $ctx = stream_context_create(['http' => ['method' => 'POST', 'header' => "Content-Type: application/json\r\n", 'content' => $body, 'timeout' => 2, 'ignore_errors' => true]]);
    @file_get_contents($url, false, $ctx);
}
function hb_version() {
    $v = json_decode((string)@file_get_contents(__DIR__ . '/version.json'), true);
    return $v['version'] ?? '1';
}
function hb_base() {
    global $CFG;
    return rtrim($CFG['site'], '/') . '/';
}
function hb_mail($to, $subject, $html, $text, $replyTo = null, $unsub = null) {
    global $CFG;
    $b = 'hbs' . bin2hex(random_bytes(8));
    $enc = fn($s) => '=?UTF-8?B?' . base64_encode($s) . '?=';
    $h  = 'From: ' . $enc($CFG['from_name']) . ' <' . $CFG['from_email'] . ">\r\n";
    $h .= 'Reply-To: ' . ($replyTo && filter_var($replyTo, FILTER_VALIDATE_EMAIL) ? $replyTo : $CFG['reply_to']) . "\r\n";
    $dom = substr(strrchr($CFG['from_email'], '@'), 1);
    $h .= 'Date: ' . date('r') . "\r\n";
    $h .= 'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $dom . ">\r\n";
    if ($unsub) {   // dezabonare cu un clic (cerută de Gmail / Yahoo pentru e-mailurile automate)
        $h .= 'List-Unsubscribe: <' . $unsub . '>, <mailto:' . $CFG['reply_to'] . "?subject=unsubscribe>\r\n";
        $h .= "List-Unsubscribe-Post: List-Unsubscribe=One-Click\r\n";
    }
    $h .= "MIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"$b\"\r\n";
    $body  = "--$b\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text));
    $body .= "--$b\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html));
    $body .= "--$b--\r\n";
    if (getenv('HBSYNC_MAIL_LOG')) { file_put_contents(getenv('HBSYNC_MAIL_LOG'), "TO: $to\nSUBJ: $subject\n$text\n-----\n", FILE_APPEND); return true; }
    return @mail($to, $enc($subject), $body, $h, '-f' . $CFG['from_email']);
}
function hb_link_mail($lead) {
    $ro = ($lead['lang'] ?? 'ro') !== 'en';
    $base = hb_base();
    $t = $lead['token'];
    $win = $base . 'd.php?t=' . $t . '&p=win';
    $mac = $base . 'd.php?t=' . $t . '&p=mac';
    $uns = $base . 'd.php?t=' . $t . '&p=unsub&l=' . ($ro ? 'ro' : 'en');
    $v = hb_version();
    if ($ro) {
        $subj = 'Linkul tău de descărcare HB Sync';
        $lines = ['Mulțumim că încerci HB Sync!', 'Primele 3 evenimente le sincronizezi și le exporți complet, gratuit.',
                  'Windows 10/11', 'Descarcă HB Sync pentru Windows', 'Mac', 'Descarcă HB Sync pentru Mac',
                  'Dacă Windows afișează „Windows protected your PC”, apasă More info → Run anyway.',
                  'Linkul e personal și merge 30 de zile. Întrebări? Răspunde la acest e-mail sau scrie-ne pe WhatsApp: +40 787 443 135.',
                  'Nu mai vrei e-mailuri de la HB Sync?', 'Dezabonare',
                  'Primești acest e-mail pentru că ai cerut descărcarea HB Sync pe horiabodeanu.ro.'];
    } else {
        $subj = 'Your HB Sync download link';
        $lines = ['Thanks for trying HB Sync!', 'Your first 3 events sync and export in full, for free.',
                  'Windows 10/11', 'Download HB Sync for Windows', 'Mac', 'Download HB Sync for Mac',
                  'If Windows shows “Windows protected your PC”, click More info → Run anyway.',
                  'The link is personal and works for 30 days. Questions? Just reply to this email or message us on WhatsApp: +40 787 443 135.',
                  'Don\'t want emails from HB Sync?', 'Unsubscribe',
                  'You get this email because you asked to download HB Sync on horiabodeanu.ro.'];
    }
    $e = fn($s) => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    $btn = fn($href, $label, $bg) => '<a href="' . $e($href) . '" style="display:inline-block;background:' . $bg . ';color:#ffffff;text-decoration:none;font-weight:600;padding:12px 22px;border-radius:10px;font-size:15px">' . $e($label) . '</a>';
    $html = '<!doctype html><html><body style="margin:0;background:#070d1a;font-family:Segoe UI,Helvetica,Arial,sans-serif;color:#e7eefb">'
          . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#070d1a"><tr><td align="center" style="padding:28px 14px">'
          . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#101b33;border:1px solid #1f2f52;border-radius:16px">'
          . '<tr><td style="padding:28px 28px 8px"><div style="font-size:22px;font-weight:700;color:#e7eefb">HB Sync <span style="font-size:13px;color:#5b6d8f;font-weight:400">' . $e($v) . '</span></div>'
          . '<p style="font-size:16px;line-height:1.5;color:#e7eefb;margin:18px 0 4px">' . $e($lines[0]) . '</p>'
          . '<p style="font-size:14px;line-height:1.5;color:#8fa2c4;margin:0 0 20px">' . $e($lines[1]) . '</p></td></tr>'
          . '<tr><td style="padding:0 28px 6px"><div style="font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:#60a5fa;margin-bottom:8px">' . $e($lines[2]) . '</div>' . $btn($win, $lines[3], '#3b82f6') . '</td></tr>'
          . '<tr><td style="padding:18px 28px 6px"><div style="font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:#60a5fa;margin-bottom:8px">' . $e($lines[4]) . '</div>' . $btn($mac, $lines[5], '#15223f') . '</td></tr>'
          . '<tr><td style="padding:20px 28px 26px"><p style="font-size:13px;line-height:1.5;color:#8fa2c4;margin:0 0 10px">' . $e($lines[6]) . '</p>'
          . '<p style="font-size:13px;line-height:1.5;color:#8fa2c4;margin:0">' . $e($lines[7]) . '</p></td></tr></table>'
          . '<p style="font-size:11px;line-height:1.6;color:#5b6d8f;margin:16px 0 0">' . $e($lines[10]) . '<br>HB Photography &amp; Films · DANCEFIT MRG S.R.L. · Galați, România · horiabodeanu.ro<br>' . $e($lines[8]) . ' <a href="' . $e($uns) . '" style="color:#5b6d8f">' . $e($lines[9]) . '</a></p>'
          . '</td></tr></table></body></html>';
    $text = $lines[0] . "\n" . $lines[1] . "\n\n" . $lines[3] . ': ' . $win . "\n" . $lines[5] . ': ' . $mac . "\n\n" . $lines[6] . "\n" . $lines[7] . "\n\n--\n" . $lines[10] . "\nHB Photography & Films · DANCEFIT MRG S.R.L. · Galați, România · horiabodeanu.ro\n" . $lines[8] . ' ' . $uns . "\n";
    return hb_mail($lead['email'], $subj, $html, $text, null, $base . 'd.php?t=' . $t . '&p=unsub&l=' . ($ro ? 'ro' : 'en'));
}
