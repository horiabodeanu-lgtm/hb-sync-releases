<?php
// HB Sync — administrare (doar pentru tine): leads.php?k=CHEIA  ·  CSV: leads.php?k=CHEIA&csv=1
// E-mailurile și licențele stau în baza de date a site-ului (tabelele <prefix>hbsync_*), rapoartele în hbsync-data/rapoarte/.
require __DIR__ . '/_lib.php';
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex');
if (!hash_equals((string)$CFG['admin_key'], (string)($_GET['k'] ?? ''))) { http_response_code(404); exit('Not found'); }
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$kq = '?k=' . rawurlencode($_GET['k']);
$warn = [];
if (!function_exists('sodium_crypto_sign_verify_detached')) $warn[] = 'PHP fără extensia sodium: activarea licențelor nu merge (cPanel ▸ Select PHP Version ▸ bifează sodium).';
if (!function_exists('mail')) $warn[] = 'Funcția mail() e oprită pe server: e-mailurile cu linkul nu pleacă.';
if (!extension_loaded('pdo_mysql')) $warn[] = 'PHP fără pdo_mysql: baza de date nu poate fi folosită (cPanel ▸ Select PHP Version ▸ bifează pdo_mysql).';
if (!hb_dbconf()) $warn[] = 'Nu găsesc wp-config.php: pune datele bazei de date în config.php (cheia db).';
if ($warn) { header('Content-Type: text/html; charset=utf-8'); echo '<body style="background:#070d1a;color:#e7eefb;font:14px Segoe UI,Arial,sans-serif;padding:16px">' . implode('', array_map(fn($w) => '<p style="background:#3b1d1d;border:1px solid #f87171;border-radius:10px;padding:10px 12px">⚠ ' . $e($w) . '</p>', $warn)); exit; }
$db = hb_db(); $L = hb_t('leads'); $LI = hb_t('licenses'); $DV = hb_t('devices');

// acțiuni pe licențe: &reset=email (eliberează toate calculatoarele) · &block=email / &unblock=email (cheie scursă, rambursare)
foreach (['reset', 'block', 'unblock'] as $act) {
    if (empty($_GET[$act])) continue;
    $em = strtolower(trim($_GET[$act]));
    $db->prepare("INSERT IGNORE INTO $LI (email, blocked, created) VALUES (?, 0, ?)")->execute([$em, hb_now()]);
    if ($act === 'reset') $db->prepare("DELETE FROM $DV WHERE email = ?")->execute([$em]);
    else $db->prepare("UPDATE $LI SET blocked = ? WHERE email = ?")->execute([$act === 'block' ? 1 : 0, $em]);
    header('Location: ' . $kq); exit;
}
$cols = ['email', 'created', 'lang', 'platform', 'news', 'downloads', 'dl_win', 'dl_mac', 'last_download', 'unsubscribed', 'requests'];
$rows = $db->query("SELECT " . implode(',', $cols) . " FROM $L ORDER BY created DESC")->fetchAll();
if (!empty($_GET['csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="hbsync-emailuri-' . date('Y-m-d') . '.csv"');
    $f = fopen('php://output', 'w'); fwrite($f, "\xEF\xBB\xBF"); fputcsv($f, $cols);
    foreach ($rows as $r) { foreach (['news', 'unsubscribed'] as $b) $r[$b] = $r[$b] ? 'da' : 'nu'; fputcsv($f, $r); }
    exit;
}
$n = count($rows); $dl = count(array_filter($rows, fn($r) => $r['downloads'] > 0)); $news = count(array_filter($rows, fn($r) => $r['news']));
require __DIR__ . '/_stats.php';
$F = hb_t('free');
$free = $db->query("SELECT device, mac, event, created FROM $F")->fetchAll();
$devs = $db->query("SELECT email, device, last_seen, first_seen FROM $DV")->fetchAll();
$licr = $db->query("SELECT email, blocked, created FROM $LI")->fetchAll();
$reps0 = glob(HB_DATA . '/rapoarte/*.json') ?: [];
$repDates = array_map(fn($f) => substr((json_decode(@file_get_contents($f), true) ?: [])['when'] ?? '', 0, 10), $reps0);
$ST = hb_stats($rows, $free, $devs, $licr, $repDates, date('Y-m-d'));
header('Content-Type: text/html; charset=utf-8');
echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>HB Sync · administrare</title>'
   . '<style>body{background:#070d1a;color:#e7eefb;font:14px Segoe UI,Arial,sans-serif;margin:0;padding:16px}table{border-collapse:collapse;width:100%;min-width:640px}td,th{border-bottom:1px solid #1f2f52;padding:7px 8px;text-align:left}th{color:#8fa2c4;font-weight:600}.w{overflow-x:auto}.k{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0 18px}.k div{background:#101b33;border:1px solid #1f2f52;border-radius:12px;padding:10px 14px}.k b{display:block;font-size:22px}a{color:#60a5fa}h2{font-size:17px;margin:28px 0 8px}</style>'
   . '<style>.bars{display:flex;align-items:flex-end;gap:3px;height:120px;background:#0b1428;border:1px solid #1f2f52;border-radius:12px;padding:12px 12px 26px;position:relative}.bars i{flex:1;background:#3b82f6;border-radius:3px 3px 0 0;min-height:2px;position:relative}.bars i.f{background:#38bdf8}.bars i:hover:after{content:attr(data-t);position:absolute;bottom:100%;left:50%;transform:translateX(-50%);background:#e7eefb;color:#070d1a;padding:3px 6px;border-radius:6px;font-size:11px;white-space:nowrap}.bars .ax{position:absolute;bottom:6px;font-size:11px;color:#5b6d8f}.split{display:flex;height:22px;border-radius:8px;overflow:hidden;margin:6px 0 2px}.split span{display:flex;align-items:center;justify-content:center;font-size:12px}.g2{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}.k div small{display:block;color:#8fa2c4;font-size:12px}.f input{background:#101b33;border:1px solid #1f2f52;color:#e7eefb;border-radius:8px;padding:7px 10px;width:260px}.f label{margin-left:12px;color:#8fa2c4}</style>'
   . '<h1 style="font-size:20px;margin:0">HB Sync · administrare</h1><p style="color:#5b6d8f;margin:4px 0 0">Actualizat ' . $e(date('d.m.Y H:i')) . ' · versiunea de pe site: ' . $e($ST['site_version']) . '</p>';
echo hb_stats_html($ST, $e);
echo '<h2>E-mailuri (' . $n . ')</h2><p class="f"><input id="q" placeholder="Caută e-mail…" oninput="flt()"><label><input type="checkbox" id="nd" onchange="flt()"> doar cine n-a descărcat</label> · <a href="' . $kq . '&csv=1">⬇ CSV / Excel</a></p>'
   . '<div class="w"><table id="tl"><tr><th>E-mail</th><th>Data</th><th>Limba</th><th>Sistem</th><th>Noutăți</th><th>Descărcări</th><th>Ultima descărcare</th><th>Licență</th></tr>';
$licSet = array_flip(array_map(fn($l) => strtolower($l['email']), $licr));
foreach ($rows as $r) echo '<tr data-d="' . (int)$r['downloads'] . '"><td>' . $e($r['email']) . '</td><td>' . $e(substr($r['created'], 0, 16)) . '</td><td>' . $e($r['lang']) . '</td><td>' . $e($r['platform']) . '</td><td>' . ($r['news'] ? 'da' : ($r['unsubscribed'] ? 'dezabonat' : 'nu')) . '</td><td>' . (int)$r['downloads'] . ($r['downloads'] ? ' (' . (int)$r['dl_win'] . ' win · ' . (int)$r['dl_mac'] . ' mac)' : '') . '</td><td>' . $e(substr((string)$r['last_download'], 0, 16)) . '</td><td>' . (isset($licSet[strtolower($r['email'])]) ? '✓' : '') . '</td></tr>';
echo '</table></div><script>function flt(){var q=document.getElementById("q").value.toLowerCase(),nd=document.getElementById("nd").checked;document.querySelectorAll("#tl tr[data-d]").forEach(function(t){t.style.display=(t.cells[0].textContent.toLowerCase().indexOf(q)>-1&&(!nd||t.dataset.d==="0"))?"":"none"})}</script>';

$lic = $db->query("SELECT l.email, l.blocked, COUNT(d.device) AS n, GROUP_CONCAT(d.name ORDER BY d.first_seen SEPARATOR ', ') AS names, MAX(d.last_seen) AS last
                   FROM $LI l LEFT JOIN $DV d ON d.email = l.email GROUP BY l.email, l.blocked ORDER BY last DESC")->fetchAll();
echo '<h2>Licențe activate</h2><div class="w"><table><tr><th>E-mail</th><th>Calculatoare</th><th>Ultima folosire</th><th></th></tr>';
foreach ($lic as $l) {
    $em = rawurlencode($l['email']);
    echo '<tr><td>' . $e($l['email']) . '</td><td>' . (int)$l['n'] . ' / 3 · ' . $e($l['names']) . '</td><td>' . $e(substr((string)$l['last'], 0, 16)) . '</td><td>'
       . '<a href="' . $kq . '&reset=' . $e($em) . '" onclick="return confirm(\'Eliberez toate calculatoarele acestei licențe?\')">eliberează</a> · '
       . ($l['blocked'] ? '<b style="color:#f87171">blocată</b> <a href="' . $kq . '&unblock=' . $e($em) . '">deblochează</a>'
                        : '<a href="' . $kq . '&block=' . $e($em) . '" onclick="return confirm(\'Blochez licența?\')">blochează</a>') . '</td></tr>';
}
echo '</table></div>';

// varianta gratuită + semnale de abuz (multe e-mailuri sau calculatoare de pe același IP)
$fr = $db->query("SELECT COUNT(DISTINCT device) AS pcs, COUNT(*) AS evs FROM $F")->fetch();
echo '<h2>Varianta gratuită</h2><div class="k"><div><b>' . (int)$fr['pcs'] . '</b>calculatoare</div><div><b>' . (int)$fr['evs'] . '</b>evenimente gratuite folosite</div></div>';
$sus = $db->query("SELECT ip, COUNT(*) AS n, GROUP_CONCAT(email ORDER BY created SEPARATOR ', ') AS emails FROM $L WHERE ip <> '' GROUP BY ip HAVING n >= 3 ORDER BY n DESC LIMIT 30")->fetchAll();
$susf = $db->query("SELECT ip, COUNT(DISTINCT device) AS n, COUNT(DISTINCT mac) AS m FROM $F WHERE ip <> '' GROUP BY ip HAVING n >= 3 ORDER BY n DESC LIMIT 30")->fetchAll();
echo '<h2>De verificat (același IP)</h2><p style="color:#5b6d8f">Mai multe e-mailuri sau calculatoare din aceeași rețea. Poate fi un studio cu mai mulți oameni, sau cineva care încearcă să ia de mai multe ori varianta gratuită. IP-ul e anonimizat.</p><div class="w"><table><tr><th>IP (anonim)</th><th>E-mailuri</th><th>Care</th></tr>';
foreach ($sus as $r) echo '<tr><td>' . $e($r['ip']) . '</td><td>' . (int)$r['n'] . '</td><td>' . $e($r['emails']) . '</td></tr>';
foreach ($susf as $r) echo '<tr><td>' . $e($r['ip']) . '</td><td colspan="2">' . (int)$r['n'] . ' calculatoare (' . (int)$r['m'] . ' plăci de rețea) au folosit varianta gratuită</td></tr>';
if (!$sus && !$susf) echo '<tr><td colspan="3" style="color:#5b6d8f">Nimic suspect.</td></tr>';
echo '</table></div>';

$reps = glob(HB_DATA . '/rapoarte/*.json') ?: [];
rsort($reps);
if (!empty($_GET['r'])) {
    $f = HB_DATA . '/rapoarte/' . preg_replace('/[^0-9a-f-]/', '', $_GET['r']) . '.json';
    if (is_file($f)) { $r = json_decode(file_get_contents($f), true); echo '<h2>Raport ' . $e($r['id']) . '</h2><pre style="white-space:pre-wrap;background:#101b33;border:1px solid #1f2f52;border-radius:12px;padding:14px;font:12px Consolas,monospace">' . $e(json_encode($r, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . '</pre>'; }
}
echo '<h2>Rapoarte de probleme (' . count($reps) . ')</h2><div class="w"><table><tr><th>Data</th><th>Tip</th><th>De la</th><th>Versiune</th><th>Mesaj</th></tr>';
foreach (array_slice($reps, 0, 50) as $f) {
    $r = json_decode(file_get_contents($f), true) ?: [];
    echo '<tr><td><a href="' . $kq . '&r=' . $e($r['id'] ?? '') . '">' . $e(substr($r['when'] ?? '', 0, 16)) . '</a></td><td>' . $e($r['kind'] ?? '') . '</td><td>' . $e($r['email'] ?? '') . '</td><td>' . $e($r['version'] ?? '') . '</td><td>' . $e(mb_substr($r['message'] ?? '', 0, 90)) . '</td></tr>';
}
echo '</table></div>';
